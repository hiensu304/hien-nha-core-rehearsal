# @hien-nha/core-domain

Hiên Nhà reusable Core, local foundation version 0.1.0. MIT. This package is private and is not published to a registry.

ESM JavaScript and TypeScript declarations are built into dist; no TypeScript runtime loader is required.

See the repository ADRs and release manifest for compatibility, limits and tested versions. No user configuration, personal content, credentials or provider implementation is included.
