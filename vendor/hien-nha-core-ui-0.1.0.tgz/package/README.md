# @hien-nha/core-ui

Hiên Nhà reusable Core, local foundation version 0.1.0. MIT. This package is private and is not published to a registry.

Native Astro components; requires Astro 7. Build/import through the explicit .astro exports.

See the repository ADRs and release manifest for compatibility, limits and tested versions. No user configuration, personal content, credentials or provider implementation is included.
